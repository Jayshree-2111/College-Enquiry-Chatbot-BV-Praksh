<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "onlinebot";

$conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");
    define("EMAILID",'bvChatbot.praksh@gmail.com');
    define('PASSWORD','JayKhu2@22');
?>